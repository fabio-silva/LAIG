#pragma once

#include "CGFobject.h"
#include "myUnitCube.h"

class CasaTeste: public CGFobject {
public:
	void draw();
};

#pragma once

#include "CGFobject.h"
class myUnitCube: public CGFobject {
public:
	void draw();
};

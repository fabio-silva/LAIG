#ifndef SPOT_H
#define SPOT_H

#include <vector>
#include "GL\gl.h"
using namespace std;

class Spot{

public:
	Spot(vector<float> location, vector<float>ambient, vector<float>diffuse, vector<float>specular, vector<float> direction, char *id, bool enabled, float angle, float exponent);
	vector<float> getLocation();
	vector<float> getAmbient();
	vector<float> getDiffuse();
	vector<float> getSpecular();
	vector<float> getDirection();
	float getAngle();
	float getExponent();
	bool isEnabled();
	char* getId();
	void setLightnr(GLenum nr);
	GLenum getLightNr();

protected:
	vector<float> location, ambient, diffuse, specular,direction;
	char *id;
	bool enabled;
	float angle,exponent;
	GLenum lightnr;
};
#endif
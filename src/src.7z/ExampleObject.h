#ifndef EXAMPLEOBJECT_H
#define EXAMPLEOBJECT_H

#include "CGFobject.h"

class ExampleObject: public CGFobject {
	public:
		void draw();
};

#endif
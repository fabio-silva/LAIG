#include "Sphere.h"

Sphere::Sphere(vector<float> data, char *cullorder):Primitiva(data, cullorder)
{
	obj = gluNewQuadric();
	GLuint esferaText;
	glGenTextures( 1, &esferaText );
	glBindTexture(GL_TEXTURE_2D, 1);
	gluQuadricTexture(obj,GL_TRUE); 
}

void Sphere::draw()
{
	if (strcmp(cullorder,"CW") == 0)
	{
		gluQuadricOrientation(obj, GLU_INSIDE);
	}
	else if (strcmp(cullorder,"CCW") == 0)
	{
		gluQuadricOrientation(obj, GLU_OUTSIDE);
	}

	gluSphere(obj, (double)data[0], (int)data[1], (int)data[2]);
}

#include "Cena.h"
#include <iostream>

Cena::Cena()
{
	activeCamera = NULL;
}

void Cena::setGlobals(float backR, float backG, float backB, float backAlpha, char *drawmode, char *shading, char *cullface, char *cullorder)
{
	this->backR = backR;
	this->backG = backG;
	this->backB = backB;
	this->backAlpha = backAlpha;
	this->drawmode = drawmode;
	this->shading = shading;
	this->cullface = cullface;
	this->cullorder = cullorder;

	activeCamera = NULL;
}

vector <Camera*> Cena::getCameras()
{
	return scene_cameras;
}

void Cena::setInitialCameraId(char* initialCameraId)
{
	this->initialCameraId = initialCameraId;
}

void Cena::addSceneCamera(Camera* camera)
{
	scene_cameras.push_back(camera);
}

void Cena::setActiveCamera(Camera *c)
{
	activeCamera = c;
}

char* Cena::getInitialCameraId()
{
	return initialCameraId;
}

void Cena::init()
{
	//glutPostRedisplay();

	glClearColor(backR,backG,backB,backAlpha); 

	glEnable(GL_LIGHTING);
	glEnable(GL_DEPTH_TEST);

	if(strcmp(shading, "flat") == 0) glShadeModel(GL_FLAT);
	else glShadeModel(GL_SMOOTH);

	if(strcmp(cullorder, "CW") == 0) glFrontFace(GL_CW);
	else glFrontFace(GL_CCW);

	int n_lights = 0;

	if(ambient_light->isDoubleSided()) glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);
	else glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_FALSE);

	if(ambient_light->isLocal()) glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);
	else  glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_FALSE);

	if(ambient_light->isEnabled()) glLightModelfv(GL_LIGHT_MODEL_AMBIENT, &ambient_light->getAmbient()[0]);

	for (int i = 0; i < omnis.size(); i++)
	{
		glLightfv(omnis[i]->getLightNr(), GL_AMBIENT, &omnis[i]->getAmbient()[0]);
		glLightfv(omnis[i]->getLightNr(), GL_DIFFUSE, &omnis[i]->getDiffuse()[0]);
		glLightfv(omnis[i]->getLightNr(), GL_SPECULAR, &omnis[i]->getSpecular()[0]);
		glLightfv(omnis[i]->getLightNr(), GL_POSITION, &omnis[i]->getLocation()[0]);

		cout << omnis[i]->getLocation()[0] << " - " << omnis[i]->getLocation()[1] << " - " << omnis[i]->getLocation()[2] << " - " << endl;

		if(omnis[i]->isEnabled()) glEnable(omnis[i]->getLightNr());
		else glDisable(omnis[i]->getLightNr());
	}

	for (int i = 0; i < spots.size(); i++)
	{
		glLightfv(spots[i]->getLightNr(), GL_AMBIENT, &spots[i]->getAmbient()[0]);
		glLightfv(spots[i]->getLightNr(), GL_DIFFUSE, &spots[i]->getDiffuse()[0]);
		glLightfv(spots[i]->getLightNr(), GL_SPECULAR, &spots[i]->getSpecular()[0]);
		glLightfv(spots[i]->getLightNr(), GL_POSITION, &spots[i]->getLocation()[0]);
		glLightfv(spots[i]->getLightNr(), GL_SPOT_DIRECTION, &spots[i]->getDirection()[0]);
		glLightf(spots[i]->getLightNr(), GL_SPOT_CUTOFF, spots[i]->getAngle());
		glLightf(spots[i]->getLightNr(), GL_SPOT_EXPONENT, spots[i]->getExponent());

		if(spots[i]->isEnabled()) glEnable(spots[i]->getLightNr());
		else glDisable(spots[i]->getLightNr());
	}
}

void Cena::display()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	

	activeCamera->render();

	for(int i = 0; i<graph.size(); i++) if(graph[i]->isRoot()) 
	{
		processNode(graph[i], NULL);
	}

	glutSwapBuffers();
}

void Cena::setAmbient(Light *ambient)
{
	ambient_light = ambient;
}

void Cena::addSpot(Spot *spot)
{
	spots.push_back(spot);
}

void Cena::addOmni(Omni *omni)
{
	omnis.push_back(omni);
}

char *Cena::getCullOrder()
{
	return cullorder;
}

void Cena::setGraph(vector<Node *> graph)
{
	this->graph = graph; 
}


void Cena::calculateMatrixes(Node *n)
{
	float newMatrix[16];
	glPushMatrix();

	glLoadMatrixf(n->getMatrix());

	if(n->getParent() != NULL) 
	{
		glMultMatrixf(n->getParent()->getMatrix());
		glGetFloatv(GL_MODELVIEW_MATRIX, newMatrix);
		n->setMatrix(newMatrix);
	}

	for(int i = 0; i < n->getChildren().size(); i++) calculateMatrixes(n->getChildren()[i]);
}
void Cena::processNode(Node *n, Material *m)
{  

	glEnable(GL_TEXTURE_2D);

	Material *actualM;

	if(n->getMaterial() != NULL) actualM = n->getMaterial();
	else actualM = m;

	if(actualM != NULL) actualM->apply();
	glEnable(GL_MODELVIEW);
	glMultMatrixf(n->getMatrix());

	for(int i = 0; i<n->getPrimitivas().size();i++)
	{

		if(strcmp(cullface,"back") == 0) 
		{
			glEnable(GL_CULL_FACE); 
			glCullFace(GL_BACK);

			if(strcmp(drawmode, "fill") == 0) 
			{
				glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
			}
			else if(strcmp(drawmode, "line") == 0) 
			{
				glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			}
			else
			{
				glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
			}

		}
		else if(strcmp(cullface,"front") == 0)
		{
			glEnable(GL_CULL_FACE); 
			glCullFace(GL_FRONT);

			if(strcmp(drawmode, "fill") == 0) 
			{
				glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
			}
			else if(strcmp(drawmode, "line") == 0) 
			{
				glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			}
			else
			{
				glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
			}
		}
		else if(strcmp(cullface,"both")==0)
		{
			glEnable(GL_CULL_FACE); 
			glCullFace(GL_FRONT_AND_BACK);

			if(strcmp(drawmode, "fill") == 0) 
			{
				glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
			}
			else if(strcmp(drawmode, "line") == 0) 
			{
				glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			}
			else
			{
				glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
			}
		}
		else
		{
			if(strcmp(drawmode, "fill") == 0) 
			{
				glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
			}
			else if(strcmp(drawmode, "line") == 0) 
			{
				glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			}
			else
			{
				glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
			}
		}
		n->getPrimitivas()[i]->draw();

		glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
	}

	for(int i = 0; i < n->getChildren().size(); i++)
	{
		glPushMatrix();
		processNode(n->getChildren()[i], actualM);
		glPopMatrix();
	}
}



char * Cena::getCullFace()
{
	return cullface;
}

void Cena::setDrawMode(char *drawmode)
{
	this->drawmode = drawmode;
}

char * Cena:: getDrawMode()
{
	return drawmode;
}
vector <Spot *> Cena::getSpots()
{
	return spots;
}

vector <Omni *> Cena::getOmnis()
{
	return omnis;
}

Cena::~Cena()
{
}

